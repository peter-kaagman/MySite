=pod

=encoding utf-8

=head1 PURPOSE

Basic tests for B<StrLength> from L<Types::Common::String>.

=head1 AUTHOR

Toby Inkster E<lt>tobyink@cpan.orgE<gt>.

=head1 COPYRIGHT AND LICENCE

This software is copyright (c) 2019-2025 by Toby Inkster.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

use strict;
use warnings;
use Test::More;
use Test::Fatal;
use Test::TypeTiny;
use Test::Requires qw(boolean);
use Types::Common::String qw( StrLength );

isa_ok(StrLength, 'Type::Tiny', 'StrLength');
is(StrLength->name, 'StrLength', 'StrLength has correct name');
is(StrLength->display_name, 'StrLength', 'StrLength has correct display_name');
is(StrLength->library, 'Types::Common::String', 'StrLength knows it is in the Types::Common::String library');
ok(Types::Common::String->has_type('StrLength'), 'Types::Common::String knows it has type StrLength');
ok(!StrLength->deprecated, 'StrLength is not deprecated');
ok(!StrLength->is_anon, 'StrLength is not anonymous');
ok(StrLength->can_be_inlined, 'StrLength can be inlined');
is(exception { StrLength->inline_check(q/$xyz/) }, undef, "Inlining StrLength doesn't throw an exception");
ok(!StrLength->has_coercion, "StrLength doesn't have a coercion");
ok(StrLength->is_parameterizable, "StrLength is parameterizable");
isnt(StrLength->type_default, undef, "StrLength has a type_default");
is(StrLength->type_default->(), '', "StrLength type_default is the empty string");

#
# The @tests array is a list of triples:
#
# 1. Expected result - pass, fail, or xxxx (undefined).
# 2. A description of the value being tested.
# 3. The value being tested.
#

my @tests = (
	fail => 'undef'                    => undef,
	pass => 'false'                    => !!0,
	pass => 'true'                     => !!1,
	pass => 'zero'                     =>  0,
	pass => 'one'                      =>  1,
	pass => 'negative one'             => -1,
	pass => 'non integer'              =>  3.1416,
	pass => 'empty string'             => '',
	pass => 'whitespace'               => ' ',
	pass => 'line break'               => "\n",
	pass => 'random string'            => 'abc123',
	pass => 'loaded package name'      => 'Type::Tiny',
	pass => 'unloaded package name'    => 'This::Has::Probably::Not::Been::Loaded',
	fail => 'a reference to undef'     => do { my $x = undef; \$x },
	fail => 'a reference to false'     => do { my $x = !!0; \$x },
	fail => 'a reference to true'      => do { my $x = !!1; \$x },
	fail => 'a reference to zero'      => do { my $x = 0; \$x },
	fail => 'a reference to one'       => do { my $x = 1; \$x },
	fail => 'a reference to empty string' => do { my $x = ''; \$x },
	fail => 'a reference to random string' => do { my $x = 'abc123'; \$x },
	fail => 'blessed scalarref'        => bless(do { my $x = undef; \$x }, 'SomePkg'),
	fail => 'empty arrayref'           => [],
	fail => 'arrayref with one zero'   => [0],
	fail => 'arrayref of integers'     => [1..10],
	fail => 'arrayref of numbers'      => [1..10, 3.1416],
	fail => 'blessed arrayref'         => bless([], 'SomePkg'),
	fail => 'empty hashref'            => {},
	fail => 'hashref'                  => { foo => 1 },
	fail => 'blessed hashref'          => bless({}, 'SomePkg'),
	fail => 'coderef'                  => sub { 1 },
	fail => 'blessed coderef'          => bless(sub { 1 }, 'SomePkg'),
	fail => 'glob'                     => do { no warnings 'once'; *SOMETHING },
	fail => 'globref'                  => do { no warnings 'once'; my $x = *SOMETHING; \$x },
	fail => 'blessed globref'          => bless(do { no warnings 'once'; my $x = *SOMETHING; \$x }, 'SomePkg'),
	fail => 'regexp'                   => qr/./,
	fail => 'blessed regexp'           => bless(qr/./, 'SomePkg'),
	fail => 'filehandle'               => do { open my $x, '<', $0 or die; $x },
	fail => 'filehandle object'        => do { require IO::File; 'IO::File'->new($0, 'r') },
	fail => 'ref to scalarref'         => do { my $x = undef; my $y = \$x; \$y },
	fail => 'ref to arrayref'          => do { my $x = []; \$x },
	fail => 'ref to hashref'           => do { my $x = {}; \$x },
	fail => 'ref to coderef'           => do { my $x = sub { 1 }; \$x },
	fail => 'ref to blessed hashref'   => do { my $x = bless({}, 'SomePkg'); \$x },
	fail => 'object stringifying to ""' => do { package Local::OL::StringEmpty; use overload q[""] => sub { "" }; bless [] },
	fail => 'object stringifying to "1"' => do { package Local::OL::StringOne; use overload q[""] => sub { "1" }; bless [] },
	fail => 'object numifying to 0'    => do { package Local::OL::NumZero; use overload q[0+] => sub { 0 }; bless [] },
	fail => 'object numifying to 1'    => do { package Local::OL::NumOne; use overload q[0+] => sub { 1 }; bless [] },
	fail => 'object overloading arrayref' => do { package Local::OL::Array; use overload q[@{}] => sub { $_[0]{array} }; bless {array=>[]} },
	fail => 'object overloading hashref' => do { package Local::OL::Hash; use overload q[%{}] => sub { $_[0][0] }; bless [{}] },
	fail => 'object overloading coderef' => do { package Local::OL::Code; use overload q[&{}] => sub { $_[0][0] }; bless [sub { 1 }] },
	fail => 'object booling to false'  => do { package Local::OL::BoolFalse; use overload q[bool] => sub { 0 }; bless [] },
	fail => 'object booling to true'   => do { package Local::OL::BoolTrue;  use overload q[bool] => sub { 1 }; bless [] },
	fail => 'boolean::false'           => boolean::false,
	fail => 'boolean::true'            => boolean::true,
	pass => 'builtin::false'           => do { no warnings; builtin->can('false') ? builtin::false() : !!0 },
	pass => 'builtin::true'            => do { no warnings; builtin->can('true') ? builtin::true() : !!1 },
#TESTS
);

while (@tests) {
	my ($expect, $label, $value) = splice(@tests, 0 , 3);
	if ($expect eq 'xxxx') {
		note("UNDEFINED OUTCOME: $label");
	}
	elsif ($expect eq 'pass') {
		should_pass($value, StrLength, ucfirst("$label should pass StrLength"));
	}
	elsif ($expect eq 'fail') {
		should_fail($value, StrLength, ucfirst("$label should fail StrLength"));
	}
	else {
		fail("expected '$expect'?!");
	}
}

#
# String with a minimum length
#

my $StrLength_2 = StrLength[2];

should_fail('',          $StrLength_2);
should_fail('1',         $StrLength_2);
should_pass('12',        $StrLength_2);
should_pass('123',       $StrLength_2);
should_pass('1234',      $StrLength_2);
should_pass('12345',     $StrLength_2);
should_pass('123456',    $StrLength_2);
should_pass('1234567',   $StrLength_2);
should_pass('12345678',  $StrLength_2);
should_pass('123456789', $StrLength_2);

is($StrLength_2->type_default, undef, "$StrLength_2 has no type_default");

# Cyrillic Small Letter Zhe - two bytes as UTF-8 but only one character
should_fail("\x{0436}" x 1, $StrLength_2);
should_pass("\x{0436}" x 2, $StrLength_2);
should_pass("\x{0436}" x 6, $StrLength_2);

#
# String with a minimum and maximum length
#

my $StrLength_2_5 = StrLength[2, 5];

should_fail('',          $StrLength_2_5);
should_fail('1',         $StrLength_2_5);
should_pass('12',        $StrLength_2_5);
should_pass('123',       $StrLength_2_5);
should_pass('1234',      $StrLength_2_5);
should_pass('12345',     $StrLength_2_5);
should_fail('123456',    $StrLength_2_5);
should_fail('1234567',   $StrLength_2_5);
should_fail('12345678',  $StrLength_2_5);
should_fail('123456789', $StrLength_2_5);
should_fail("\x{0436}" x 1, $StrLength_2_5);
should_pass("\x{0436}" x 2, $StrLength_2_5);
should_fail("\x{0436}" x 6, $StrLength_2_5);

#
# Overloaded objects are not allowed
#

{
	package Local::OL::Stringy;
	use overload q[""] => sub { ${$_[0]} };
	sub new { my ($class, $str) = @_; bless(\$str, $class) }
}

my $abc_obj = Local::OL::Stringy->new('abc');
is("$abc_obj", "abc");
should_fail($abc_obj, $StrLength_2_5);

#
# But you can do this to create a type accepting a overloaded objects
# that stringify to a string matching $StrLength_2_5.
#

use Types::Standard qw(Overload);
my $Overloaded_StrLength_2_5
	= Overload->of(q[""])->stringifies_to($StrLength_2_5);
should_pass($abc_obj, $Overloaded_StrLength_2_5);
# ... though that doesn't accept real strings.
should_fail('abc', $Overloaded_StrLength_2_5);

#
# Union type constraint to the rescue!
#

my $Union_2_5 = $StrLength_2_5 | $Overloaded_StrLength_2_5;
should_pass($abc_obj, $Union_2_5);
should_pass('abc', $Union_2_5);


done_testing;
